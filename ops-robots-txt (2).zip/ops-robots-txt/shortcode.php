<?php
if (! function_exists( 'ops_submit_postFun' )) {
	function ops_submit_postFun(){
    $postname = ''; $postcontent = ''; $errorMsg = '';
	if(isset($_POST['submit'])  && sanitize_text_field($_POST['submit']) == 'submit' && check_admin_referer( 'ops_user_submit_action', 'ops_of_userpost_field' ))
	{
		    $error = '';
			$postname = sanitize_text_field($_POST['post_name']);
		    $postcontent = wp_kses_post($_POST['post_content']); 
		    $category = sanitize_text_field(filter_var($_POST['category'], FILTER_VALIDATE_INT)); 
		   // $postexpert = sanitize_text_field($_POST['post_expert']);
		    if( empty( $postname ) )
		        $error .= '<p class="is_error">Please enter post name.</p>';
		    if( empty( $postcontent ) )
		        $error .= '<p class="is_error">Please enter post content.</p>';
		    if( empty( $error ) )
		    {
				$new_post = array(
				    'post_title' => $postname,
				    'post_type' => 'post',
				    'post_staus' => 'draft', 
				    'post_content' => $postcontent,
				    'post_date' => date( 'Y-m-d H:i:s', time() ),
				    'post_category' => array( $category)
				);
				// Catch post ID
			$post_id = absint(wp_insert_post( $new_post ));
        if ($post_id) {
			echo $success = '<div class="alert alert-success fade show">Thank you for submitting your post, I will check and approve it soon. </div>';
			$adminEmail = get_option( 'admin_email' );
			$getSiteUrl = get_site_url();
			$adminEmailSubject = 'New Post Submit -' .$postname;
			 
			$adminEmailMessage = 'Hello, <br>'
				
			.'<br /><br /><strong>Someone have submited a new blog article on our website : </strong> '.$postname
				
			.'<br /><br /><strong>Content : </strong> '.$postcontent

			.'<br /> <br />Thanks & Regards <br>' .$getSiteUrl;
				
			wp_mail($adminEmail, $adminEmailSubject, $adminEmailMessage);

		if ( isset($_FILES['image']) && sanitize_file_name($_FILES["image"]["name"]) != '') {
		 
		        $upload = wp_upload_bits(sanitize_file_name($_FILES["image"]["name"]), null, file_get_contents($_FILES["image"]["tmp_name"]) );
		 
		            $post_id = $post_id; //set post id to which you need to set featured image
		            $filename = $upload['file'];
		            $wp_filetype = wp_check_filetype($filename, null);
		            $featureattachment = array(
		                'post_mime_type' => $wp_filetype['type'],
		                'post_title' => sanitize_file_name($filename),
		                'post_content' => '',
		                'post_status' => 'inherit'
		            );
		 
		            $attachment_id = wp_insert_attachment( $featureattachment, $filename, $post_id );
		 
		            if ( ! is_wp_error( $attachment_id ) ) {
		                require_once(ABSPATH . 'wp-admin/includes/image.php');
		
		                $attachment_data = wp_generate_attachment_metadata( $attachment_id, $filename );
		                wp_update_attachment_metadata( $attachment_id, $attachment_data );
		                set_post_thumbnail( $post_id, $attachment_id );
		            }
		       }
		    } else {
		    	$error = "User Submit Post Error";
		    }
		}
	else
		{

		 $errorMsg = $error;

	   }
	}
	ob_start();
    ?>
	<section class="ops contact-wrap">
		<div class="insidebox">
			<h2>Write Your Guest Post</h2>
			 <form action="" method="POST" enctype="multipart/form-data" class="contact-form">
	    	<div class="row">
	        <div class="col-sm-12 PostName">
	            <div class="input-block">
	                <label for="">Post Name *</label>
	                 <input type="text" name="post_name" value="<?php if($postname){ echo esc_html($postname); } ?>" class="form-control">
	            </div>
	        </div>
	        <!--<div class="col-sm-12 PostExcerpt">-->
	        <!--    <div class="input-block">-->
	        <!--        <label for="">Write an Excerpt</label>-->
	        <!--        <input type="text" name="post_expert" class="form-control" value="<?php // if($postexpert){ echo esc_html($postexpert); } ?>">-->
	        <!--    </div>-->
	        <!--</div>-->
	        <div class="col-sm-12 PostContent">
	            <div class="input-block textarea">
	                <label for="">Drop your content here *</label>
	                 <textarea rows="4" type="text" id="opseditor" name="post_content" class="form-control" autofocus>
	                 	<?php if($postcontent){ echo esc_html($postcontent); } ?>
	                 </textarea>
	            </div>
	        </div>
	        <div class="col-sm-12 PostCategory">
	            <div class="input-block">
	                <label for="">Category</label>
	                <select name="category" class="form-control">
	                	<option value="">--- Choose a category ---</option>
			        <?php $categories = get_categories( array(
			        	'post_type' => 'post',
					    'orderby' => 'name',
					    'order'   => 'ASC',
					    'hide_empty' => 0,
					    'child_of' => 0,

					) );
					foreach( $categories as $category ) {
					 echo '<option value="' . $category->term_id . '">' . esc_html($category->name) . '</option>';   
					} ?> 
			</select>      
		      </div>
	        </div>
	        <div class="col-sm-12 FeaturedImage">
	            <div class="input-block">
	                <label for="">Featured Image</label>
	                <input type="file" name="image" class="form-control featureimage">
	            </div>
	        </div>
	       <?php wp_nonce_field( 'ops_user_submit_action', 'ops_of_userpost_field' ); ?>
	        <div class="col-sm-12">
	        	<input type="submit" name="submit" value="<?php esc_attr_e('submit') ?>" class="btn square-button">
	        </div>
	       </div>
	    </form>
	    <div class="errorbox mb-2">
	    	<?php echo $errorMsg; ?>
	    </div>
	</div>
</section>
<?php 
    if ( ! is_admin() ) {
    ?>
        <script>var editor = new Simditor({
          textarea: $('#opseditor')
          //optional options
        });</script>
    <?php
    }
   
    return ob_get_clean();
	}
}
if ( ! shortcode_exists( 'ops-user-submitted-posts' ) ) {
   if ( function_exists( 'ops_submit_postFun' )) {
	add_shortcode( 'ops-user-submitted-posts', 'ops_submit_postFun' );
	}
}
?>